import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VehicleListPage } from './vehicle-list-page';

describe('VehicleListPage', () => {
  let component: VehicleListPage;
  let fixture: ComponentFixture<VehicleListPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VehicleListPage],
    }).compileComponents();

    fixture = TestBed.createComponent(VehicleListPage);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
